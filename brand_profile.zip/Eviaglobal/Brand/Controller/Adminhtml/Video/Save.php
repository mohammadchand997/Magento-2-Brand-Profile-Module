<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Controller\Adminhtml\Video;

use Psr\Log\LoggerInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Controller\Result\Json;


class Save extends \Magento\Backend\App\Action
{

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Eviaglobal\Brand\Api\VideoRepositoryInterface
     */
    private $videoRepository;

    /**
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var \Eviaglobal\Brand\Api\Data\VideoInterface
     */
    private $videoDataFactory;


    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Eviaglobal\Brand\Api\VideoRepositoryInterface $videoRepository,
        LoggerInterface $logger,
        JsonFactory $resultJsonFactory,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        \Eviaglobal\Brand\Api\Data\VideoInterface $videoDataFactory
    ) {
        parent::__construct($context);
        $this->videoRepository   = $videoRepository;
        $this->logger            = $logger;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->dataObjectHelper  = $dataObjectHelper;
        $this->videoDataFactory  = $videoDataFactory;
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute(): Json
    {
        $brandId = $this->getRequest()->getParam('parent_id', false);
        $videoId = $this->getRequest()->getParam('video_id', false);
        $data    = $this->getRequest()->getParams();
        $error   = false;
        try{
            $model = $this->_objectManager->create(\Eviaglobal\Brand\Model\Video::class)->load($videoId);
            if (!$model->getId() && $videoId) {
                $error = true;
                $message = __('This video no longer exists.');
            }
            $model->setData($data);
            if ($videoId) {
                $message = __('Brand video has been updated.');
            } else {
                $message = __('New brand address has been added.');
            }
            $savedVideo =$model->save();;
            $videoId = $savedVideo->getVideoId();
        } catch (NoSuchEntityException $e) {
            $this->logger->critical($e);
            $error = true;
            $message = __('There is no brand with such id.');
        } catch (LocalizedException $e) {
            $error = true;
            $message = __($e->getMessage());
            $this->logger->critical($e);
        } catch (\Exception $e) {
            $error = true;
            $message = __('We can\'t change brand video right now.');
            $this->logger->critical($e);
        }
        $videoId    = empty($videoId) ? null : $videoId;
        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData(
            [
                'messages' => $message,
                'error' => $error,
                'data' => [
                    'video_id' => $videoId
                ]
            ]
        );

        return $resultJson;
    }
}

