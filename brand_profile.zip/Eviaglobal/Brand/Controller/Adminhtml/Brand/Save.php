<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Controller\Adminhtml\Brand;

use Magento\Framework\Exception\LocalizedException;
use Eviaglobal\Brand\Helper\Data;
use Eviaglobal\Brand\Model\BrandFactory;

class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        Data $helperData,
        BrandFactory $brandFactory
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->helperData = $helperData;
        $this->brandFactory = $brandFactory;
        $this->_eventManager = $eventManager;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        //echo '<pre>';print_r($data);die();
        if ($data) {

            $title = str_replace(' ', '-', strtolower($data['general']['title'])); 
            $checkBrand = $this->isBrandExsist($title);  
            $url_key = ($checkBrand && $checkBrand['url_key']) ? $this->helperData->increment_string($checkBrand['url_key']) : $title;
            //$url_key = $title;
            $option_id = isset($data['general']['option_id']) ? $data['general']['option_id'] : '';
            $discounts = isset($data['general']['discounts']) ? json_encode($data['general']['discounts']) : json_encode([]);
            $media_gallery = isset($data['media']['media_gallery']) ? json_encode($data['media']['media_gallery']) : '';
            $listing_banner = isset($data['media']['listing_banner'][0]['name']) ? $data['media']['listing_banner'][0]['name'] : '';
            $home_banner = isset($data['media']['home_banner'][0]['name']) ? $data['media']['home_banner'][0]['name'] : '';
            $attributes = (array)$data['attributes'];

            $formData = [
                'title' => $data['general']['title'],
                'email' => $data['general']['email'],
                'website_url' => $data['general']['website_url'],
                'city'       => $attributes['city'],
                'option_id'  => $option_id,
                'country_id' => $attributes['country_id'],
                'about'      => $data['general']['about'],
                'logo'       => $data['media']['logo'][0]['name'],
                'banner'     => $data['media']['banner'][0]['name'],
                'discounts'  => $discounts,
                'price_from' => $data['price_from'],
                'price_to'   => $data['price_to'],
                'attributes' => json_encode($data['attributes'], JSON_UNESCAPED_SLASHES),
                'media_gallery' => $media_gallery,
                'meta_title' => $data['others_detail']['meta_title'],
                'meta_keywords' => $data['others_detail']['meta_keywords'],
                'meta_description' => $data['others_detail']['meta_description'],
                'display_on_frontend' => $data['general']['display_on_frontend'],
                'show_on_homepage' => $data['general']['show_on_homepage'],
                'listing_banner' => $listing_banner,
                'home_banner' => $home_banner,
                'contact_name' => $data['others_detail']['contact_name'],
                'designation' => $data['others_detail']['designation'],
                'business_category' => $data['others_detail']['business_category'],
                'are_you' => $data['others_detail']['are_you'],
                'postcode' => $data['others_detail']['postcode'],
                'address_1' => $data['others_detail']['address_1'],
                'address_2' => $data['others_detail']['address_2'],
                'phone' => $data['others_detail']['phone'],
                'email_c' => $data['others_detail']['email_c']

            ];

            //echo '<pre>';print_r($checkUrlKey);die();

            $productData = [
                'name' => $data['general']['title'],
                'image' => $data['media']['logo'][0]['url'],
                'attributes' => json_encode($data['attributes']),
            ];

            $id = $this->getRequest()->getParam('brand_id');
            $formData['brand_id'] = $id;
            $model = $this->_objectManager->create(\Eviaglobal\Brand\Model\Brand::class)->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This Brand no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
            if($model->getId()){
                $product = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($model['product_id']);
                if($product->getId()){
                    $this->helperData->addProductImageById($model['product_id'], $data['media']['logo'][0]['url']);
                    $attributes = (array)$data['attributes'];
                    $attributes['city'] = $model->getId();
                    $attributes['brand_country'] = $attributes['country_id'];
                    $attributes['custom_supplier'] = $model->getId();
                    foreach ($attributes as $key => $value) {
                        $this->helperData->addProductAttributeValueById($model['product_id'], $key, $value);
                    }   
                }else{
                    $this->setBrandProduct($productData, $model->getId());
                }

                // $attributes = (array)$data['attributes'];
                // $attributes['city'] = $model->getId();
                // $attributes['brand_country'] = $data['general']['country_id'];
                // if ($attributes) {
                //     foreach ($attributes as $key => $value) {
                //         $this->helperData->addProductAttributeValueById($model['product_id'], $key, $value);
                //     }   
                // }
                $data['brand_id'] = $model->getId();
                $this->_eventManager->dispatch(
                    'controller_action_postdispatch_eviaglobal_brand_brand_save', 
                    ['data' => $data]
                );        
            }
            
            $model->setData($formData);
        
            try {
                $model->save();
                $lastId = $model->getId();
                if(!$id && $lastId){
                    $this->setBrandProduct($productData, $lastId);
                }
                $this->messageManager->addSuccessMessage(__('Brand Details Saved Successfully.'));
                $this->dataPersistor->clear('eviaglobal_brand_brand');
                // $this->_eventManager->dispatch(
                //     'controller_action_postdispatch_eviaglobal_brand_brand_save', 
                //     ['data' => $data]
                // );        
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['brand_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the Brand.'));
            }
        
            $this->dataPersistor->set('eviaglobal_brand_brand', $data);
            return $resultRedirect->setPath('*/*/edit', ['brand_id' => $this->getRequest()->getParam('brand_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    public function isBrandExsist($title){
        $barnd = $this->brandFactory->create()->getCollection()->addFieldToFilter('url_key', $title)->getFirstItem();
        return $barnd->getData();
    }

    public function setBrandProduct($productData, $brandId){

        $productId = $this->helperData->createCustomProduct($productData);
        $resource = $this->_objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('eviaglobal_brand_brand');
        $sql = "Update ".$tableName." Set product_id =".$productId." where brand_id = ".$brandId."";
        $connection->query($sql);
    }
}

