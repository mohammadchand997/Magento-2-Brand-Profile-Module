<?php
declare(strict_types=1);

namespace Eviaglobal\Brand\Controller\Adminhtml\Collection;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Eviaglobal\Brand\Model\ResourceModel\Collection\CollectionFactory;
use Psr\Log\LoggerInterface;
use Magento\Framework\Controller\Result\JsonFactory;

class MassDelete extends Action
{
    public $collectionFactory;

    public $cFactory;

    public $filter;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        \Eviaglobal\Brand\Model\CollectionFactory $cFactory,
        LoggerInterface $logger,
        JsonFactory $resultJsonFactory
    ) {
        $this->filter            = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->cFactory      = $cFactory;
        $this->logger            = $logger;
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $error = false;
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        try {
            $count = 0;
            foreach ($collection as $model) {
                $model = $this->cFactory->create()->load($model->getCollectionId());
                $model->delete();
                $count++;
            }
            $message = __('A total of %1 record(s) have been deleted.', $count);
        } catch (NoSuchEntityException $e) {
            $message = __('There is no such video entity to delete.'.$e->getMessage());
            $error = true;
            $this->logger->critical($e);
        } catch (LocalizedException $e) {
            $message = __($e->getMessage());
            $error = true;
            $this->logger->critical($e);
        } catch (\Exception $e) {
            $message = __('We can\'t mass delete the collection right now.'.$e->getMessage());
            $error = true;
            $this->logger->critical($e);
        }

        $resultJson = $this->resultJsonFactory->create();
        $resultJson->setData(
            [
                'message' => $message,
                'error' => $error,
            ]
        );

        return $resultJson;
    }

    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Eviaglobal_Brand::delete');
    }
}