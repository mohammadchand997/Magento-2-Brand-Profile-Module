<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Model;

use Eviaglobal\Brand\Api\Data\CollectionInterface;
use Magento\Framework\Model\AbstractModel;

class Collection extends AbstractModel implements CollectionInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Eviaglobal\Brand\Model\ResourceModel\Collection::class);
    }

    /**
     * @inheritDoc
     */
    public function getCollectionId()
    {
        return $this->getData(self::COLLECTION_ID);
    }

    /**
     * @inheritDoc
     */
    public function setCollectionId($collectionId)
    {
        return $this->setData(self::COLLECTION_ID, $collectionId);
    }

    /**
     * @inheritDoc
     */
    public function getParentId()
    {
        return $this->getData(self::PARENT_ID);
    }

    /**
     * @inheritDoc
     */
    public function setParentId($parentId)
    {
        return $this->setData(self::PARENT_ID, $parentId);
    }

    /**
     * @inheritDoc
     */
    public function getProductId()
    {
        return $this->getData(self::PRODUCT_ID);
    }

    /**
     * @inheritDoc
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }
}
