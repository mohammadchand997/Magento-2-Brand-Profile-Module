<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Model;

use Eviaglobal\Brand\Api\CollectionRepositoryInterface;
use Eviaglobal\Brand\Api\Data\CollectionInterface;
use Eviaglobal\Brand\Api\Data\CollectionInterfaceFactory;
use Eviaglobal\Brand\Api\Data\CollectionSearchResultsInterfaceFactory;
use Eviaglobal\Brand\Model\ResourceModel\Collection as ResourceCollection;
use Eviaglobal\Brand\Model\ResourceModel\Collection\CollectionFactory as CollectionCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class CollectionRepository implements CollectionRepositoryInterface
{

    /**
     * @var CollectionCollectionFactory
     */
    protected $collectionCollectionFactory;

    /**
     * @var ResourceCollection
     */
    protected $resource;

    /**
     * @var CollectionInterfaceFactory
     */
    protected $collectionFactory;

    /**
     * @var Collection
     */
    protected $searchResultsFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;


    /**
     * @param ResourceCollection $resource
     * @param CollectionInterfaceFactory $collectionFactory
     * @param CollectionCollectionFactory $collectionCollectionFactory
     * @param CollectionSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceCollection $resource,
        CollectionInterfaceFactory $collectionFactory,
        CollectionCollectionFactory $collectionCollectionFactory,
        CollectionSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->collectionFactory = $collectionFactory;
        $this->collectionCollectionFactory = $collectionCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(CollectionInterface $collection)
    {
        try {
            $this->resource->save($collection);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the collection: %1',
                $exception->getMessage()
            ));
        }
        return $collection;
    }

    /**
     * @inheritDoc
     */
    public function get($collectionId)
    {
        $collection = $this->collectionFactory->create();
        $this->resource->load($collection, $collectionId);
        if (!$collection->getId()) {
            throw new NoSuchEntityException(__('Collection with id "%1" does not exist.', $collectionId));
        }
        return $collection;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->collectionCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(CollectionInterface $collection)
    {
        try {
            $collectionModel = $this->collectionFactory->create();
            $this->resource->load($collectionModel, $collection->getCollectionId());
            $this->resource->delete($collectionModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Collection: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($collectionId)
    {
        return $this->delete($this->get($collectionId));
    }
}
