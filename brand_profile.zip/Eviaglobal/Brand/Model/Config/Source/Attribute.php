<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Model\Config\Source;
use \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory;

class Attribute implements \Magento\Framework\Option\ArrayInterface
{
    protected $attributeCollectionFactory;


    public function __construct(
        CollectionFactory $attributecollectionFactory
    ){
        $this->attributeCollectionFactory = $attributecollectionFactory;
    }

    public function toOptionArray()
    {
        $attributeCollection = $this->attributeCollectionFactory->create();
        foreach($attributeCollection->getItems() as $item){
            $options[] = [
                'value' => $item->getAttributeId(),
                'label' => $item->getFrontendLabel()
            ];
        }
        return $options;
    }
}
