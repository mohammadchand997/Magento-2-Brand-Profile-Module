<?php

namespace Eviaglobal\Brand\Block\Adminhtml;

use Magento\Backend\Block\Template;
//use Eviaglobal\Brand\Model\ImageGalleryFactory;

class GalleryImage extends Template
{
    protected $imageGalleryFactory;

    public function __construct(
        Template\Context $context,
        /*ImageGalleryFactory $imageGalleryFactory,*/
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->imageGalleryFactory = $imageGalleryFactory;
    }

    public function getMediaGalleryImages()
    {
        /*$imageGallery = $this->imageGalleryFactory->create();
        $collection = $imageGallery->getCollection();

        // Prepare the image paths to pass to the form UI component
        $imagePaths = [];
        foreach ($collection as $item) {
            $imagePaths[] = [
                'name' => $item->getImagePath(),
                'url' => $this->getViewFileUrl($item->getImagePath())
            ];
        }*/

        $imagePaths[] = [
                'name' => 'collection/gallery/',
                'url' => $this->getViewFileUrl('collection/gallery/')
            ];

        return $imagePaths;
    }
}
