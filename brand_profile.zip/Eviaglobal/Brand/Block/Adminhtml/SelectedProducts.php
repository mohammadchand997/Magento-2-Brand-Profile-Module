<?php

namespace Eviaglobal\Brand\Block\Adminhtml;

class SelectedProducts extends \Magento\Backend\Block\Template
{
    /**
     * Block template
     *
     * @var string
     */
    protected $_template = 'Eviaglobal_Brand::brand/selected_assign_products.phtml';

    /**
     * @var \Eviaglobal\Brand\Block\Adminhtml\Category\Tab\Product
     */
    protected $blockGrid;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;

    /**
     * @var \Magento\Framework\Json\EncoderInterface
     */
    protected $jsonEncoder;

    /**
     * @var \Eviaglobal\Brand\Model\ResourceModel\Collection\CollectionFactory
     */
    protected $productFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context                           $context
     * @param \Magento\Framework\Registry                                       $registry
     * @param \Magento\Framework\Json\EncoderInterface                          $jsonEncoder
     * @param \RH\CustProductGrid\Model\ResourceModel\Collection\CollectionFactory $productFactory
     * @param array                                                             $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder,
        \Eviaglobal\Brand\Model\ResourceModel\Collection\CollectionFactory $productFactory,
        array $data = []
    ) {
        $this->registry = $registry;
        $this->jsonEncoder = $jsonEncoder;
        $this->productFactory = $productFactory;
        parent::__construct($context, $data);
    }

    /**
     * Retrieve instance of grid block
     *
     * @return \Magento\Framework\View\Element\BlockInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getBlockGrid()
    {
        if (null === $this->blockGrid) {
            $this->blockGrid = $this->getLayout()->createBlock(
                'Eviaglobal\Brand\Block\Adminhtml\Tab\SelectedProductgrid',
                'brand.selected.product'
            );
        }
        return $this->blockGrid;
    }

    /**
     * Return HTML of grid block
     *
     * @return string
     */
    public function getGridHtml()
    {
        return $this->getBlockGrid()->toHtml();
    }

    /**
     * @return string
     */
    public function getProductsJson()
    {
        return '{}';
        $collection_id  = $this->getRequest()->getParam('collection_id');
        if($collection_id){
            $productFactory = $this->productFactory->create();
            //$productFactory->addFieldToSelect(['product_id', 'position']);
            $productFactory->addFieldToFilter('collection_id', ['eq' => $collection_id]);
            $result = [];
            if (!empty($productFactory->getData())) {
                foreach ($productFactory->getData() as $rhProducts) {
                    $result[$rhProducts['products']] = '';
                }
                return $this->jsonEncoder->encode($result);
            }
        }
        return '{}';
    }

    public function getItem()
    {
        return $this->registry->registry('my_item');
    }
}