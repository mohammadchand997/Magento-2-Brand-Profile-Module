<?php
declare(strict_types=1);

namespace Eviaglobal\Brand\Block\Adminhtml\Edit\Video;

use Eviaglobal\Brand\Model\VideoFactory;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\UrlInterface;
use Eviaglobal\Brand\Model\ResourceModel\Video;
use Eviaglobal\Brand\Model\VideoRepository;

/**
 * Class for common code for buttons on the create/edit address form
 */
class GenericButton
{
    /**
     * @var VideoFactory
     */
    private $videoFactory;

    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @var Video
     */
    private $videoResourceModel;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var VideoRepository
     */
    private $videoRepository;

    /**
     * @param AddressFactory $addressFactory
     * @param UrlInterface $urlBuilder
     * @param Address $addressResourceModel
     * @param RequestInterface $request
     * @param AddressRepository $addressRepository
     */
    public function __construct(
        videoFactory $videoFactory,
        UrlInterface $urlBuilder,
        Video $videoResourceModel,
        RequestInterface $request,
        VideoRepository $videoRepository
    ) {
        $this->videoFactory = $videoFactory;
        $this->urlBuilder = $urlBuilder;
        $this->videoResourceModel = $videoResourceModel;
        $this->request = $request;
        $this->videoRepository = $videoRepository;
    }

    /**
     * Return video Id.
     *
     * @return int|null
     */
    public function getVideoId()
    {
        $video = $this->videoFactory->create();

        $videoId = $this->request->getParam('video_id');
        $this->videoResourceModel->load(
            $video,
            $videoId
        );

        return $video->getVideoId() ?: null;
    }

    /**
     * Get customer id.
     *
     * @return int|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getBrandId()
    {
        $videoId = $this->request->getParam('video_id');

        $video = $this->videoRepository->get($videoId);

        return $video->getParentId() ?: null;
    }

    /**
     * Generate url by route and parameters
     *
     * @param   string $route
     * @param   array $params
     * @return  string
     */
    public function getUrl($route = '', array $params = []): string
    {
        return $this->urlBuilder->getUrl($route, $params);
    }
}
