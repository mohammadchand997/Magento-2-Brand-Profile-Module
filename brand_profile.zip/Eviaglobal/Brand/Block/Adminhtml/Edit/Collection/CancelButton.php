<?php
declare(strict_types=1);
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Eviaglobal\Brand\Block\Adminhtml\Edit\Collection;

use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;
use Eviaglobal\Brand\Block\Adminhtml\Edit\Collection\GenericButton;

/**
 * Class CancelButton
 */
class CancelButton extends GenericButton implements ButtonProviderInterface
{
    /**
     * @inheritdoc
     *
     * @return array
     */
    public function getButtonData()
    {
        return [
            'label' => __('Cancel'),
            'on_click' => '',
            'data_attribute' => [
                'mage-init' => [
                    'Magento_Ui/js/form/button-adapter' => [
                        'actions' => [
                            [
                                'targetName' => 'eviaglobal_brand_brand_form.areas.collection.collection.brand_collection_update_modal',
                                'actionName' => 'closeModal'
                            ],
                        ],
                    ],
                ],
            ],
            'sort_order' => 20
        ];
    }
}
