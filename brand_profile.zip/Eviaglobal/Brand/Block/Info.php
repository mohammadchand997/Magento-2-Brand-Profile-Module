<?php

namespace Eviaglobal\Brand\Block;

use Magento\Framework\View\Element\Template;
use Eviaglobal\Brand\Api\BrandRepositoryInterface;
use Eviaglobal\Brand\Model\ResourceModel\Collection\CollectionFactory;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Catalog\Block\Product\ImageBuilder;
use Magento\Eav\Model\Config;
use Magento\Catalog\Model\ResourceModel\Eav\Attribute;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Pricing\Price\FinalPrice;
use Magento\Framework\Pricing\Render;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Eviaglobal\Brand\Model\BrandFactory;
use Magento\Customer\Model\Session;
use Eviaglobal\Brand\Model\VideoFactory;

class Info extends \Magento\Contact\Block\ContactForm
{
    protected $brandRepository;

    protected $storeManager;

    protected $currentBrand;

    protected $mediaUrl;

    protected $countryFactory;

    protected $collectionFactory;

    protected $serializer;

    protected $productCollectionFactory;

    protected $imageBuilder;

    protected $priceHelper;

    protected $eavConfig;

    protected $attributeResource;

    protected $_scopeConfig;

    protected $brandFactory;

    public function __construct(
        Template\Context $context,
        \Magento\Directory\Block\Data $directoryBlock,
        BrandRepositoryInterface $brandRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Directory\Model\CountryFactory $countryFactory,
        CollectionFactory $collectionFactory,
        SerializerInterface $serializer,
        ProductCollectionFactory $productCollectionFactory,
        ImageBuilder $imageBuilder,
        \Magento\Framework\Pricing\Helper\Data $priceHelper,
        Config $eavConfig,
        Attribute $attributeResource,
        ScopeConfigInterface $scopeConfig,
        BrandFactory $brandFactory,
        Session $customerSession,
        \Magento\Customer\Api\CustomerRepositoryInterfaceFactory $customerRepositoryFactory,
        VideoFactory $videoFactory,
        array $data = []
    ){
        parent::__construct($context, $data);
        $this->_isScopePrivate = true;
        $this->directoryBlock  = $directoryBlock;
        $this->brandRepository = $brandRepository;
        $this->storeManager    = $storeManager;
        $this->countryFactory  = $countryFactory;
        $this->collectionFactory = $collectionFactory;
        $this->serializer = $serializer;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->imageBuilder = $imageBuilder;
        $this->priceHelper  = $priceHelper;
        $this->eavConfig = $eavConfig;
        $this->attributeResource = $attributeResource;
        $this->_scopeConfig = $scopeConfig;
        $this->brandFactory = $brandFactory;
        $this->customerSession = $customerSession;
        $this->customerRepository = $customerRepositoryFactory->create();
        $this->videoFactory = $videoFactory;
        $this->_initBrand();
    }

    protected function _initBrand(){
        $id = $this->getBrandId();
        $this->mediaUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA );
        if($id && empty($this->currentBrand)){
            $this->currentBrand = $this->brandRepository->get($id);
        }
    }

    public function getVideoGallery(){

        $id = $this->getBrandId();
        if($id){
            $collection = $this->videoFactory->create()->getCollection();
            $collection->addFieldToFilter('parent_id', $id);
            return $collection->getData();
        }
        return '';
        // if(!empty($this->currentBrand)){
        //     return $this->currentBrand->getData('media_gallery');
        // }
        // return '';
    }

    public function getMediaGallery(){
        if(!empty($this->currentBrand)){
            return $this->currentBrand->getData('media_gallery');
        }
        return '';
    }

    public function getBannerImageUrl(){
        if(!empty($this->currentBrand)){
            return $this->mediaUrl.'tmp/imageUploader/images/'.$this->currentBrand->getData('banner');
        }
        return $this->mediaUrl.'tmp/imageUploader/images/banner_placeholder.jpg';
    }

    public function getLogoImageUrl(){
        if(!empty($this->currentBrand)){
            return $this->mediaUrl.'tmp/imageUploader/images/'.$this->currentBrand->getData('logo');
        }
        return $this->mediaUrl.'tmp/imageUploader/images/logo_placeholder.jpg';
    }

    public function getBrandInfo(){
        if(!empty($this->currentBrand)){
            $country = $this->countryFactory->create()->loadByCode($this->currentBrand->getData('country_id'));
            $info    = '<strong>'.$this->currentBrand->getData('title').'</strong> , '.$this->currentBrand->getData('city');
            $info .= '<br/>'.$country->getName();
            return $info;
        }  
        return '';
    }

    public function getWebsiteUrl(){
        if(!empty($this->currentBrand)){
            return $this->currentBrand->getData('website_url');
        }
        return "javascript:void(0);";
    }

    public function getBrandDescription(){
        if(!empty($this->currentBrand)){
            return $this->currentBrand->getData('about');
        }
        return '';
    }

    public function getCollections(){
        $id = $this->getBrandId();
        if($id){
            $collection = $this->collectionFactory->create();
            $collection->addFieldToFilter('parent_id', $id);
            $collection->setOrder('sort_order','ASC')->load();
            $collection->getSelect()->limit(3);
            return $collection->getData();
        }
        return [];
    }

    public function getDownloadFileCompleteUrl($filename){
        return $this->getDownloadFilePrefixUrl().$filename;
    }

    public function getCollectionProducts($field){
        $productIds = $this->serializer->unserialize($field);
        if($productIds){
            $collection = $this->productCollectionFactory->create();
            $collection->addAttributeToSelect('*');
            $collection->getSelect()->reset(\Magento\Framework\DB\Select::WHERE);
            $collection->addFieldToFilter('entity_id', array('in' => $productIds));
            $collection->load();
            
            return $collection; 
        }
        return [];
    }

    public function getPriceRange(){
        if(!empty($this->currentBrand)){
            $formattedPriceFrom = $this->priceHelper->currency($this->currentBrand->getData('price_from'), true, false);
            $formattedPriceTo   = $this->priceHelper->currency($this->currentBrand->getData('price_to'), true, false);
            return $formattedPriceFrom.' - '.$formattedPriceTo;
        }
        return '';
    }

    public function getAttributes(){
        if(!empty($this->currentBrand)){
            $attirbutes = (array)$this->serializer->unserialize($this->currentBrand->getAttributes());
            unset($attirbutes["city"]);
            unset($attirbutes["country_id"]);
            $html = '';
            foreach($attirbutes as $attribute_code => $values){
                $attribute = $this->eavConfig->getAttribute('catalog_product', $attribute_code);
                $options = $attribute->getSource()->getAllOptions();
                if ($attribute && $attribute->getId()) {
                    $html .= $attribute->getDefaultFrontendLabel()."<br/>";
                    $selectedOptionLabel = [];
                    foreach($options as $_option){
                        if(empty($_option['value'])) continue;
                        if(in_array($_option['value'], $values)){
                            $selectedOptionLabel[] = $_option['label'];
                        }
                    }
                    $html .= implode(', ', $selectedOptionLabel);   
                }
            }
            return $html;
        }
        return '';
    }

    public function getProductPrice(Product $product)
    {
        $priceRender = $this->getPriceRender();

        $price = '';
        if ($priceRender) {
            $price = $priceRender->render(
                FinalPrice::PRICE_CODE,
                $product,
                [
                    'include_container' => true,
                    'display_minimal_price' => true,
                    'zone' => Render::ZONE_ITEM_LIST,
                    'list_category_page' => true
                ]
            );
        }

        return $price;
    }

    protected function getDownloadFilePrefixUrl(){
        return $this->mediaUrl.'collection/files/';
    }

    public function getImage($product, $imageId, $attributes = [])
    {
        return $this->imageBuilder->create($product, $imageId, $attributes);
    }

    protected function getPriceRender()
    {
        return $this->getLayout()->getBlock('product.price.render.default')
            ->setData('is_product_list', true);
    }

    public function getConfig($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getBrandId(){

        $urlKey = $this->getRequest()->getParam('key');
        $barnd = $this->brandFactory->create()->getCollection()->addFieldToFilter('url_key', $urlKey)->getFirstItem();
        return $barnd->getId();
    }

    public function getCustomerData()
    {   
        $getdata = '';
        if($this->customerSession->isLoggedIn()) {

            $customerId = $this->customerSession->getId();
            $customer = $this->customerRepository->getById($customerId);
            $getdata = $customer;
        }
        return $getdata;
    }

}
