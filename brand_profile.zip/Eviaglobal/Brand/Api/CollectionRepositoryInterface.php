<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface CollectionRepositoryInterface
{

    /**
     * Save Collection
     * @param \Eviaglobal\Brand\Api\Data\CollectionInterface $collection
     * @return \Eviaglobal\Brand\Api\Data\CollectionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Eviaglobal\Brand\Api\Data\CollectionInterface $collection
    );

    /**
     * Retrieve Collection
     * @param string $collectionId
     * @return \Eviaglobal\Brand\Api\Data\CollectionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($collectionId);

    /**
     * Retrieve Collection matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Eviaglobal\Brand\Api\Data\CollectionSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Collection
     * @param \Eviaglobal\Brand\Api\Data\CollectionInterface $collection
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Eviaglobal\Brand\Api\Data\CollectionInterface $collection
    );

    /**
     * Delete Collection by ID
     * @param string $collectionId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($collectionId);
}
