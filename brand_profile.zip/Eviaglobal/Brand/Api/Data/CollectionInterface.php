<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Api\Data;

interface CollectionInterface
{

    const COLLECTION_ID = 'collection_id';
    const PRODUCT_ID = 'product_id';
    const PARENT_ID = 'parent_id';

    /**
     * Get collection_id
     * @return string|null
     */
    public function getCollectionId();

    /**
     * Set collection_id
     * @param string $collectionId
     * @return \Eviaglobal\Brand\Collection\Api\Data\CollectionInterface
     */
    public function setCollectionId($collectionId);

    /**
     * Get parent_id
     * @return string|null
     */
    public function getParentId();

    /**
     * Set parent_id
     * @param string $parentId
     * @return \Eviaglobal\Brand\Collection\Api\Data\CollectionInterface
     */
    public function setParentId($parentId);

    /**
     * Get product_id
     * @return string|null
     */
    public function getProductId();

    /**
     * Set product_id
     * @param string $productId
     * @return \Eviaglobal\Brand\Collection\Api\Data\CollectionInterface
     */
    public function setProductId($productId);
}
