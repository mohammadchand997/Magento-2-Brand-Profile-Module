<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Api\Data;

interface BrandInterface
{

    const BRAND_ID = 'brand_id';
    const ABOUT = 'about';
    const COUNTRY = 'country';
    const WEBSITE_URL = 'website_url';
    const OPTION_ID = 'option_id';
    const TITLE = 'title';
    const BANNER = 'banner';
    const VIDEOS = 'videos';
    const CITY = 'city';
    const LOGO = 'logo';

    /**
     * Get brand_id
     * @return string|null
     */
    public function getBrandId();

    /**
     * Set brand_id
     * @param string $brandId
     * @return \Eviaglobal\Brand\Brand\Api\Data\BrandInterface
     */
    public function setBrandId($brandId);

    /**
     * Get title
     * @return string|null
     */
    public function getTitle();

    /**
     * Set title
     * @param string $title
     * @return \Eviaglobal\Brand\Brand\Api\Data\BrandInterface
     */
    public function setTitle($title);

    /**
     * Get logo
     * @return string|null
     */
    public function getLogo();

    /**
     * Set logo
     * @param string $logo
     * @return \Eviaglobal\Brand\Brand\Api\Data\BrandInterface
     */
    public function setLogo($logo);

    /**
     * Get banner
     * @return string|null
     */
    public function getBanner();

    /**
     * Set banner
     * @param string $banner
     * @return \Eviaglobal\Brand\Brand\Api\Data\BrandInterface
     */
    public function setBanner($banner);

    /**
     * Get about
     * @return string|null
     */
    public function getAbout();

    /**
     * Set about
     * @param string $about
     * @return \Eviaglobal\Brand\Brand\Api\Data\BrandInterface
     */
    public function setAbout($about);

    /**
     * Get website_url
     * @return string|null
     */
    public function getWebsiteUrl();

    /**
     * Set website_url
     * @param string $websiteUrl
     * @return \Eviaglobal\Brand\Brand\Api\Data\BrandInterface
     */
    public function setWebsiteUrl($websiteUrl);

    /**
     * Get option_id
     * @return string|null
     */
    public function getOptionId();

    /**
     * Set option_id
     * @param string $optionId
     * @return \Eviaglobal\Brand\Brand\Api\Data\BrandInterface
     */
    public function setOptionId($optionId);

    /**
     * Get videos
     * @return string|null
     */
    public function getVideos();

    /**
     * Set videos
     * @param string $videos
     * @return \Eviaglobal\Brand\Brand\Api\Data\BrandInterface
     */
    public function setVideos($videos);

    /**
     * Get city
     * @return string|null
     */
    public function getCity();

    /**
     * Set city
     * @param string $city
     * @return \Eviaglobal\Brand\Brand\Api\Data\BrandInterface
     */
    public function setCity($city);

    /**
     * Get country
     * @return string|null
     */
    public function getCountry();

    /**
     * Set country
     * @param string $country
     * @return \Eviaglobal\Brand\Brand\Api\Data\BrandInterface
     */
    public function setCountry($country);
}

