<?php

declare(strict_types=1);

namespace Eviaglobal\Brand\Ui\Config;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Eviaglobal\Brand\Model\ResourceModel\Collection\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
/**
 * Class CollectionDataProvider
 */
class CollectionDataProvider extends AbstractDataProvider
{
    /**
     * @var array
     */
    private $loadedData;

    protected $storeManager;

    /**
     * CustomDataProvider constructor.
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        StoreManagerInterface $storeManager,
        array $meta = [],
        array $data = []
    ) {
        $this->collection    = $collectionFactory->create();
        $this->storeManager  = $storeManager;
        parent::__construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            $meta,
            $data
        );
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (null !== $this->loadedData) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $collection) {
            // echo '<pre>';
            // print_r($collection->getData());
            // die;
            $this->loadedData[$collection->getId()] = $collection->getData();
            
            if(isset($collection) && isset($this->loadedData[$collection->getId()])){
                $getGalleryCollection = $this->loadedData[$collection->getId()]['gallery_collection'];
                $decodeGalleryCollection = json_decode($getGalleryCollection);
                $products = (array)json_decode($this->loadedData[$collection->getId()]['products']);
                
                $downloadable_file = $this->loadedData[$collection->getId()]['downloadable_file'];
                $videos = $this->loadedData[$collection->getId()]['videos'];

                unset($this->loadedData[$collection->getId()]['gallery_collection']);
                unset($this->loadedData[$collection->getId()]['downloadable_file']);
                unset($this->loadedData[$collection->getId()]['videos']);

                $this->loadedData[$collection->getId()]['downloadable_file'] = [];
                
                $this->loadedData[$collection->getId()]['downloadable_file'][0]['url'] = $this->getMediaUrl().$downloadable_file;
                $this->loadedData[$collection->getId()]['downloadable_file'][0]['name'] = $downloadable_file;
                $this->loadedData[$collection->getId()]['downloadable_file'][0]['type'] = 'application/pdf';
                $this->loadedData[$collection->getId()]['downloadable_file'][0]['size'] = 1234;
                $this->loadedData[$collection->getId()]['downloadable_file'][0]['exists'] = 1;

                $this->loadedData[$collection->getId()]['collection_videos'] = json_decode($videos);
                $this->loadedData[$collection->getId()]['gallery_collection'] = $decodeGalleryCollection;
                $this->loadedData[$collection->getId()]['brand_products'] = $products;
            }   
        }
        return $this->loadedData;
    }

     /**
     * {@inheritdoc}
     * @since 101.0.0
     */
    public function getMeta()
    {
        $meta = parent::getMeta();
        return $meta;
    }

    public function getMediaUrl()
    {
        $mediaUrl = $this->storeManager->getStore()
            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'collection/files/';
        return $mediaUrl;
    }
}
