<?php
namespace Monstershop\Rules\Ui\Component\Form\Element;


class Attributes implements \Magento\Framework\Data\OptionSourceInterface
{
    public function toOptionArray()
    {
        return [
            ['value' => '', 'label' => __('None')],
            ['value' => 1, 'label' => __('one')],
            ['value' => 2, 'label' => __('two')]
        ];
    }
}
