<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Eviaglobal\Brand\Observer;

use Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\Event\Observer;
use Eviaglobal\Brand\Helper\Data;
use Magento\Catalog\Api\Data\ProductTierPriceInterfaceFactory;
use Magento\Catalog\Api\ScopedProductTierPriceManagementInterface;

class AddUpdateTierPrice implements ObserverInterface
{
    /**
     * @var Helper
     */
    protected $_helper;

    /**
     * \Magento\Eav\Model\Entity\Attribute
     */
    protected $attribute;

    protected $collectionFactory;

    /**
     * @var ScopedProductTierPriceManagementInterface
     */
    protected $tierPrice;

    /**
     * @var ProductTierPriceInterfaceFactory
     */
    protected $productTierPriceFactory;

    protected $resourceConnection;

    public function __construct(
        Data $_helper,
        \Magento\Eav\Model\Entity\Attribute $attribute,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $collectionFactory,
        ScopedProductTierPriceManagementInterface $tierPrice,
        ProductTierPriceInterfaceFactory $productTierPriceFactory,
        \Magento\Framework\App\ResourceConnection $resourceConnection
    ){
        $this->_helper    = $_helper;
        $this->attribute  = $attribute;
        $this->collectionFactory = $collectionFactory;
        $this->tierPrice = $tierPrice;
        $this->productTierPriceFactory = $productTierPriceFactory;
        $this->resourceConnection = $resourceConnection;
    }

    public function execute(Observer $observer)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
       $postData      = $observer->getData('data');
       if(empty($postData) || !isset($postData['general']['discounts']['discounts'])){
            return $this;
       }
       //echo "<pre>";print_r($postData);die();
       $brandId = $postData['brand_id'];
       $discounts     = $postData['general']['discounts']['discounts'];
       // $brandAttributeId = $this->_helper->getAttribute();
       $qty           = 1;
       if($brandId){
            //$attributeCode = $this->attribute->load($brandAttributeId)->getAttributeCode();
            $collection = $this->collectionFactory->create();
            $collection->addFieldToSelect('*');
            $collection->addAttributeToFilter('custom_supplier', $brandId);

            foreach($collection as $_product){
                $product = $objectManager->create('Magento\Catalog\Model\Product')->load($_product->getId());
                $this->removeExistingTierPrices($product->getId());
                foreach($discounts as $_discount){
                    $tierPrice[] = [
                        'website_id' => 0,
                        'cust_group' => $_discount['customer_group'],
                        'price_qty'  => 1,
                        'percentage_value' => $_discount['discount_percentage']
                    ];
                }
                $product->setTierPrice($tierPrice);
                $product->save();
            }
        }
        return $this;
    }

    protected function removeExistingTierPrices($productId){
        $connection = $this->resourceConnection->getConnection();
        $tableName  = $this->resourceConnection->getTableName('catalog_product_entity_tier_price'); 
        $sqlQuery   = "DELETE FROM {$tableName} WHERE entity_id={$productId}";
        $connection->query($sqlQuery);
    }

}

