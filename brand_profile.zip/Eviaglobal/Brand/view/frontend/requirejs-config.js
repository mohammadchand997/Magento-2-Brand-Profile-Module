var config = {
    paths: {
        owlcarousel: "Eviaglobal_Brand/js/owl.carousel"
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    }
};