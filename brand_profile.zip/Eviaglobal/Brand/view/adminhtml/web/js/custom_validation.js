$("form").serializeArray();
require(
        [
            'Magento_Ui/js/lib/validation/validator',
            'jquery',
            'mage/translate'
    ], function(validator, $){
            $(document).ready(function() {
                /*$('#your-form-id').on('submit', function(event) {
                    if (!$('#city').val() || !$('#country_id').val() || !$('#style').val() || !$('#spaces').val() ) {
                        event.preventDefault(); // Prevent form submission
                        $('#tab_attributes').trigger('click');
                    }
                });*/
                $('#save_and_continue').on('click', function() {
                    // Your custom click event logic here
                    if(!$('#city').val() || !$('#country_id').val() || !$('#style').val() || !$('#spaces').val() || jQuery('#attributes').find('.mage-error').length > 0){
                        $('#tab_attributes').trigger('click');
                    }
                });
                $('#save').on('click', function() {
                    // Your custom click event logic here
                    if(!$('#city').val() || !$('#country_id').val() || !$('#style').val() || !$('#spaces').val() || jQuery('#attributes').find('.mage-error').length > 0){
                        $('#tab_attributes').trigger('click');
                    }
                });
            });
});